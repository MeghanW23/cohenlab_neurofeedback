import pygame
import random
import time


# Set a fixed seed
random.seed(42)  # You can use any integer value here

print("This Task is a Go/No-Go Aimed at activating the rIFG and ACC.")

""" PATHS """
buzz: pygame.Surface = pygame.image.load("/workdir/run_docker/buzz.png")
alien: pygame.Surface = pygame.image.load("/workdir/run_docker/alien.png")
fixation: pygame.Surface = pygame.image.load("/workdir/run_docker/fixationcross.png")
pressed_a: pygame.Surface = pygame.image.load("/workdir/run_docker/pressed_a.png")

default_output_log_directory: str = "/workdir/run_docker/output_logs"

""" EXPERIMENTAL PARAMETERS """
n_trials: int = 140
ISI_min: int = 250
ISI_max: int = 1250
ISI_step: int = 250

""" FUNCTIONS """
# print a dictionary to terminal in a more readable way
def print_data_dictionary(dictionary: dict, dictionary_name: str = None) -> None:  # print Dictionary in a nicer-looking way
    if dictionary_name is not None:
        print("\n---")
        print(f"Printing Info on {dictionary_name} Below: ")
    else:
        print(f"Printing Dictionary Information Below: \n")

    for key, value in dictionary.items():
        print("---")

        if isinstance(dictionary[key], dict): # if this key in the dictionary is a subdictionary, format a different way
            print(f"dictionary: {key}")
            for subkey, subvalue in dictionary[key].items():
                print(f"  {subkey}: {subvalue}")
        else:
            print(f"key: {key}, value: {value}")

    print("---\n")

# get the participant ID from terminal window (check for issues with inputted pid)
def get_participant_id() -> str:
    acceptable_characters: list = ["p", "P", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]

    while True:
        Retrying: bool = False
        pid: str = input("Enter PID: ")

        if not pid.startswith("p") and not pid.startswith("P"):
            print("Please Assure Your Inputted PID starts with 'P' or 'p'")
            Retrying: bool = True

        if len(pid) == 1:
            print("Please Assure Your PID Follows Syntax: the letter 'p' followed by numbers only.")
            Retrying: bool = True

        for character in pid:
            iterator: int = 0
            if character not in acceptable_characters:
                if iterator == 0:  # only print out this line once (not for every unacceptable character)
                    print("Please Assure Your PID Follows Syntax: the letter 'p' followed by numbers only.")
                iterator += 1
                Retrying: bool = True

        if not Retrying:
            print(f"OK, Using PID: {pid}")
            break

    return pid

# handle key presses, record participant behavior, pass experimental info to blit the trial
def handle_trial(DataDictionary: dict, trial_number: int) -> dict:
    trial_dictionary: dict = DataDictionary[f"trial{trial_number}"]  # pull this trial's dictionary from main dictionary
    pressed_a_counter: int = 0  # count times 'a' is pressed

    start_time: float = time.time()  # Record the start time

    conditions_list: list = ["buzz", "buzz", "buzz", "alien"]  # Participants have a 75% chance of getting Buzz
    random.shuffle(conditions_list)
    stimulus: str = random.choice(conditions_list)  # chose random condition from conditions_list
    print(f"trial_type:{stimulus}")

    trial_dictionary["trial_type"]: str = stimulus
    trial_dictionary["start_time"]: float = start_time

    while True:
        blit_trial(stimulus=stimulus)

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN and event.key == pygame.K_a:
                print("Pressed A")

                pressed_a_counter += 1

                if pressed_a_counter == 1:
                    # get reaction time
                    current_time: float = time.time()  # Get the current time
                    elapsed_time: float = current_time - start_time  # Calculate elapsed time
                    trial_dictionary["time_to_first_a_press"]: float = elapsed_time

                second_monitor_width: int = DataDictionary["whole_session_data"]["mri_screen_width"]
                second_monitor_height: int = DataDictionary["whole_session_data"]["mri_screen_height"]
                press_a_width: int = DataDictionary["whole_session_data"]["press_a_width"]
                press_a_height: int = DataDictionary["whole_session_data"]["press_a_height"]

                screen.blit(pressed_a_resized, (second_monitor_width // 1.6 - press_a_width // 2, second_monitor_height // 3.4 - press_a_height // 2))  # report keypress 'a'

                pygame.display.flip()

                if stimulus == "buzz":
                    trial_dictionary["result"]: str = "hit"

                elif stimulus == "alien":
                    trial_dictionary["result"]: str = "false alarm"

                break

        current_time: float = time.time()  # Get the current time
        elapsed_time: float = current_time - start_time  # Calculate elapsed time
        if elapsed_time >= 1:  # Check if a second has passed
            trial_dictionary["pressed_a_num_of_times"]: int = pressed_a_counter
            if pressed_a_counter == 0:
                if stimulus == "buzz":
                    trial_dictionary["result"]: str = "miss"
                elif stimulus == "alien":
                    trial_dictionary["result"]: str = "correct rejection"

            print("A second has passed.")
            trial_dictionary["full_second_has_passed"] = True
            break

    return DataDictionary

# depending on the stimulus type, blit either buzz or the alien to the screen
def blit_trial(stimulus):
    second_monitor_width: int = DataDictionary["whole_session_data"]["mri_screen_width"]
    second_monitor_height: int = DataDictionary["whole_session_data"]["mri_screen_height"]

    if stimulus == "buzz":
        buzz_width: int = DataDictionary["whole_session_data"]["buzz_width"]
        buzz_height: int = DataDictionary["whole_session_data"]["buzz_height"]
        screen.blit(buzz_resized, (second_monitor_width // 1.8 - buzz_width // 2, second_monitor_height // 2 - buzz_height // 2))

        pygame.display.flip()
    else:
        alien_width: int = DataDictionary["whole_session_data"]["alien_width"]
        alien_height: int = DataDictionary["whole_session_data"]["alien_height"]
        screen.blit(alien_resized, (second_monitor_width // 1.8 - alien_width // 2, second_monitor_height // 2 - alien_height // 2))

        pygame.display.flip()
    return None

# show instructions to participants, wait for scanner to send 's' to mac to start
def show_instructions(DataDictionary: dict) -> None:
    second_monitor_width: int = DataDictionary["whole_session_data"]["mri_screen_width"]
    second_monitor_height: int = DataDictionary["whole_session_data"]["mri_screen_height"]

    font = pygame.font.Font(None, 55)
    instructions = [
        "Welcome to the Task!",
        "Press 'A' using your left thumb when you see Buzz (the astronaut).",
        "Do NOT press anything when you see Alien.",
        "Ready..",
        "Set",
        "Go!"
    ]

    # Calculate the total height needed for all instructions to be centered
    line_height = font.get_linesize()
    total_text_height = line_height * len(instructions)

    # Calculate the initial y_offset to vertically center the text block
    y_offset = (second_monitor_height - total_text_height) // 2

    screen.fill((0, 0, 0))

    # Render and display each line of instructions centered vertically and horizontally
    for line in instructions:
        text = font.render(line, True, (255, 255, 255))  # White text
        text_rect = text.get_rect(center=(second_monitor_width // 2, y_offset))
        screen.blit(text, text_rect)
        y_offset += line_height  # Increment y-position for each new line based on line height

    pygame.display.flip()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN and event.key == pygame.K_s:
                return None
            else:
                time.sleep(0.1)

 #Save data to a csv file in output directory
import csv
import os
from datetime import datetime

# Ensure you define this default directory or set it where needed
def save_to_log_file(dictionary: dict = None, create_log_file: bool = False, pid: str = None, output_log_directory: str = default_output_log_directory, output_log_path: str = None,  # Adding output_log_path to function parameters
trial: int = None):
    # Check if an output_log_path is provided or needs to be created
    if create_log_file:
        now = datetime.now()
        timestamp = now.strftime("%Y%m%d_%Hh%Mm%Ss")
        output_dir_filename = f"{pid}_{timestamp}_rifg_task_log.csv"
        output_log_path = os.path.join(output_log_directory, output_dir_filename)

        with open(output_log_path, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["Created Output Log File for", pid, "at", timestamp])

        print(f"Created Log File. Find At: {output_log_path}")

        return output_log_path

    # Ensure output_log_path is set if not creating a new log file
    if output_log_path is None:
        raise ValueError("output_log_path must be provided if not creating a new log file.")

    # Append data to an existing log file
    with open(output_log_path, 'a', newline='') as file:
        writer = csv.writer(file)
        if trial is not None:
            writer.writerow([f"====== Trial: {trial} ======"])
        for key, value in dictionary.items():
            writer.writerow([key, value])

#define function to show task completion message
def show_end_message():
    second_monitor_width= DataDictionary["whole_session_data"]["mri_screen_width"]
    second_monitor_height= DataDictionary["whole_session_data"]["mri_screen_height"]

    font = pygame.font.Font(None, 55)
    message = "You have now completed the task. Thank you for participating!"
    text = font.render(message, True, (255, 255, 255))  # White text
    text_rect = text.get_rect(center=(second_monitor_width // 2, second_monitor_height // 2))  # Centered text

    screen.fill((0,0,0))
    screen.blit(text, text_rect)

    pygame.display.flip()

    time.sleep(5) #show the message on screen for 5 seconds

""" SETUP """
pygame.init()  # initialize Pygame

# Create Dictionary to pull all needed data in, then Update Data Dictionary with the Experimental Parameters
DataDictionary: dict = {"whole_session_data": {
    'n_trials': n_trials,
    'ISI_min': ISI_min,
    'ISI_max': ISI_max,
    'ISI_step': ISI_step
}}

pid: str = get_participant_id()  # get participant ID by asking experimenter to input it via command line

DataDictionary["whole_session_data"]["pid"]: str = pid  # add participant id to whole session data dictionary

# Set up display
screen_info: pygame.display.Info = pygame.display.Info()
SCREEN_WIDTH: int = screen_info.current_w
SCREEN_HEIGHT: int = screen_info.current_h
DataDictionary["whole_session_data"]["experimenter_screen_width"]: int = SCREEN_WIDTH
DataDictionary["whole_session_data"]["experimenter_screen_height"]: int = SCREEN_HEIGHT

os.environ['SDL_VIDEO_WINDOW_POS']: str = f'{SCREEN_WIDTH + 1},0'

all_monitors: list = pygame.display.list_modes()  # Get information about all monitors
second_monitor_index: int = 1  # Assuming you want to display on the second monitor
second_monitor_width, second_monitor_height = all_monitors[second_monitor_index]

print(f"Second monitor resolution: {second_monitor_width}x{second_monitor_height}")
DataDictionary["whole_session_data"]["mri_screen_width"]: int = second_monitor_width
DataDictionary["whole_session_data"]["mri_screen_height"]: int = second_monitor_height

screen: pygame.Surface = pygame.display.set_mode((second_monitor_width, second_monitor_height), pygame.FULLSCREEN | pygame.NOFRAME)  # Set screen dimensions

# Resize Loaded Pygame images
new_width_buzz: int = 600  # Desired width for buzz
new_height_buzz: int = 600  # Desired height for buzz
buzz_resized: pygame.Surface = pygame.transform.scale(buzz, (new_width_buzz, new_height_buzz))
buzz_width: int = buzz_resized.get_width()
buzz_height: int = buzz_resized.get_height()
DataDictionary["whole_session_data"]["buzz_width"]: int = buzz_width
DataDictionary["whole_session_data"]["buzz_height"]: int = buzz_height


new_width_alien: int = 800
new_height_alien: int = 600
alien_resized: pygame.Surface = pygame.transform.scale(alien, (new_width_alien, new_height_alien))
alien_width: int = alien_resized.get_width()
alien_height: int = alien_resized.get_height()
DataDictionary["whole_session_data"]["alien_width"]: int = alien_width
DataDictionary["whole_session_data"]["alien_height"]: int = alien_height


new_width_fixation: int = 400
new_height_fixation: int = 400
fix_resized: pygame.Surface = pygame.transform.scale(fixation, (new_width_fixation, new_height_fixation))
fixation_width: int = fix_resized.get_width()
fixation_height: int = fix_resized.get_height()
DataDictionary["whole_session_data"]["fixation_width"]: int = fixation_width
DataDictionary["whole_session_data"]["fixation_height"]: int = fixation_height

new_width_keypress: int = 800
new_height_keypress: int = 600
pressed_a_resized: pygame.Surface = pygame.transform.scale(pressed_a, (new_width_keypress, new_height_keypress))
press_a_width: int = pressed_a_resized.get_width()
press_a_height: int = pressed_a_resized.get_height()
DataDictionary["whole_session_data"]["press_a_width"]: int = press_a_width
DataDictionary["whole_session_data"]["press_a_height"]: int = press_a_height

print_data_dictionary(DataDictionary, dictionary_name="All Session Data")  # print session data to terminal

output_log_path = save_to_log_file(create_log_file=True, pid=pid)  # create log file
save_to_log_file(dictionary=DataDictionary["whole_session_data"], output_log_path=output_log_path)
show_instructions(DataDictionary=DataDictionary)  # Show Instructions

""" MAIN TASK LOOP """
# Run Each Trial
for trial in range(1, n_trials + 1):
    print(f" ==== Starting Trial {trial} ==== ")

    # make a sub-dictionary in the data dictionary for this trial
    DataDictionary[f"trial{trial}"]: dict = {}
    trial_dictionary = DataDictionary[f"trial{trial}"]

    screen.fill((0, 0, 0))  # fill the screen black

    screen.blit(fix_resized, (second_monitor_width // 1.8 - fixation_width // 2, second_monitor_height // 2 - fixation_height // 2)) #  show fixation cross

    pygame.display.flip()  # flip to monitor

    ISI: int = random.randrange(start=ISI_min, stop=ISI_max, step=ISI_step)  # get random inter stimulus interval (in ms)
    print(f"ISI: {ISI}")
    trial_dictionary["ISI"] = ISI  # add ISI to trial_dictionary

    time.sleep(ISI / 1000.0)  # do the ISI wait time

    DataDictionary = handle_trial(DataDictionary=DataDictionary, trial_number=trial)   # Run the Buzz/Alien Part of Trial

    print_data_dictionary(trial_dictionary)  # print the data to the terminal

    save_to_log_file(dictionary=trial_dictionary, output_log_path=output_log_path, trial=trial) # save trial information to the log

show_end_message()

