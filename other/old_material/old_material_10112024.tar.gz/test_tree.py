import subprocess 
result = subprocess.run(["tree"])
print(result)
