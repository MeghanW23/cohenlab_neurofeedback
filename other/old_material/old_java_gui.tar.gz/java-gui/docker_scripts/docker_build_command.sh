sudo docker build -t java_gui .
