docker run -it --rm \
-v  /Users/meghan/cohenlab_neurofeedback/other/java-gui/test_docker_java_gui:/test_docker_java_gui \
-e DISPLAY=10.23.229.77:0 \
java_test_gui /bin/bash 
 